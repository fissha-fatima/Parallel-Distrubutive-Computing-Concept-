
public class TradingEngineApp {
    public static void main(String[] args) {
        long now = System.currentTimeMillis();

        TradeEvent e1 = new FIXOrderEvent(
                "FIX-GW01", now, 2500.00, "ORD-99201");

        TradeEvent e2 = new ReutersQuoteEvent(
                "REUTERS-A", now, 2498.50, 2498.25, 2499.75);

        TradeEvent e3 = new TradeEvent(
                "GENERIC-FEED", now, 1000.00);

        System.out.println("=== Polymorphic Event Dispatching ===");

        e1.dispatch();
        e2.dispatch();
        e3.dispatch();
    }
}
