
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class InventoryCatalogManager {

    private static final int NUM_THREADS = 10;
    private static final int TOTAL_OPS = 50000;
    private static final int CATALOG_SIZE = 1000;

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== E-Commerce Inventory Concurrency Benchmark ===");

        benchmarkSynchronizedMap();
        benchmarkConcurrentMap();
    }

    public static void benchmarkSynchronizedMap()
            throws InterruptedException {

        Map<String, Integer> map =
                Collections.synchronizedMap(new HashMap<>());

        for (int i = 0; i < CATALOG_SIZE; i++) {
            map.put("PROD-" + i, 100);
        }

        ExecutorService exec =
                Executors.newFixedThreadPool(NUM_THREADS);

        long start = System.currentTimeMillis();

        for (int t = 0; t < NUM_THREADS; t++) {
            exec.submit(() -> {
                for (int i = 0; i < TOTAL_OPS / NUM_THREADS; i++) {
                    String key = "PROD-" + (i % CATALOG_SIZE);

                    synchronized (map) {
                        Integer val = map.get(key);

                        if (val != null) {
                            map.put(key, val + 1);
                        }
                    }
                }
            });
        }

        exec.shutdown();
        exec.awaitTermination(1, TimeUnit.MINUTES);

        long time = System.currentTimeMillis() - start;
        double seconds = Math.max(time / 1000.0, 0.001);

        System.out.printf(
                "1. Synchronized Map Time: %d ms | Throughput: %.2f ops/sec%n",
                time, TOTAL_OPS / seconds
        );
    }

    public static void benchmarkConcurrentMap()
            throws InterruptedException {

        Map<String, Integer> map = new ConcurrentHashMap<>();

        for (int i = 0; i < CATALOG_SIZE; i++) {
            map.put("PROD-" + i, 100);
        }

        ExecutorService exec =
                Executors.newFixedThreadPool(NUM_THREADS);

        long start = System.currentTimeMillis();

        for (int t = 0; t < NUM_THREADS; t++) {
            exec.submit(() -> {
                for (int i = 0; i < TOTAL_OPS / NUM_THREADS; i++) {
                    String key = "PROD-" + (i % CATALOG_SIZE);

                    map.computeIfPresent(key, (k, v) -> v + 1);
                }
            });
        }

        exec.shutdown();
        exec.awaitTermination(1, TimeUnit.MINUTES);

        long time = System.currentTimeMillis() - start;
        double seconds = Math.max(time / 1000.0, 0.001);

        System.out.printf(
                "2. ConcurrentHashMap Time: %d ms | Throughput: %.2f ops/sec%n",
                time, TOTAL_OPS / seconds
        );
    }
}
