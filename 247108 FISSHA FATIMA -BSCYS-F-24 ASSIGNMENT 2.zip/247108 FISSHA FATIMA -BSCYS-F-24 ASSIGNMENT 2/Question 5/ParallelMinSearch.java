
public class ParallelMinSearch extends SensorSearchEngine
        implements Runnable {

    private double minResult;

    public ParallelMinSearch(double[] data, int start, int end) {
        super(data, start, end);
    }

    @Override
    public double processGrid() {
        double min = sensorData[startIdx];

        for (int i = startIdx + 1; i < endIdx; i++) {
            if (sensorData[i] < min) {
                min = sensorData[i];
            }
        }

        return min;
    }

    @Override
    public void run() {
        minResult = processGrid();
    }

    public double getMinResult() {
        return minResult;
    }
}
