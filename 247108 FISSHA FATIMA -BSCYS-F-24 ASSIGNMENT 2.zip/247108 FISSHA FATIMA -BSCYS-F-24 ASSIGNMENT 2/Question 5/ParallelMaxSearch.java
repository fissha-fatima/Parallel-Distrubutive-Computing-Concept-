
public class ParallelMaxSearch extends SensorSearchEngine
        implements Runnable {

    private double maxResult;

    public ParallelMaxSearch(double[] data, int start, int end) {
        super(data, start, end);
    }

    @Override
    public double processGrid() {
        double max = sensorData[startIdx];

        for (int i = startIdx + 1; i < endIdx; i++) {
            if (sensorData[i] > max) {
                max = sensorData[i];
            }
        }

        return max;
    }

    @Override
    public void run() {
        maxResult = processGrid();
    }

    public double getMaxResult() {
        return maxResult;
    }
}
