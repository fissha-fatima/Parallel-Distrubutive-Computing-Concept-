
import java.util.Random;

public class SensorGridMonitorApp {

    public static void main(String[] args)
            throws InterruptedException {

        int size = 50000;
        double[] data = new double[size];

        Random rnd = new Random(77);

        for (int i = 0; i < size; i++) {
            data[i] = -20.0 + rnd.nextDouble() * 140.0;
        }

        int threads = 4;
        int chunk = size / threads;

        ParallelMinSearch[] mins =
                new ParallelMinSearch[threads];

        ParallelMaxSearch[] maxs =
                new ParallelMaxSearch[threads];

        Thread[] tMins = new Thread[threads];
        Thread[] tMaxs = new Thread[threads];

        for (int i = 0; i < threads; i++) {
            int s = i * chunk;
            int e = (i == threads - 1)
                    ? size : (i + 1) * chunk;

            mins[i] = new ParallelMinSearch(data, s, e);
            maxs[i] = new ParallelMaxSearch(data, s, e);

            tMins[i] = new Thread(mins[i]);
            tMaxs[i] = new Thread(maxs[i]);

            tMins[i].start();
            tMaxs[i].start();
        }

        double gMin = Double.MAX_VALUE;
        double gMax = -Double.MAX_VALUE;

        for (int i = 0; i < threads; i++) {
            tMins[i].join();
            tMaxs[i].join();

            if (mins[i].getMinResult() < gMin) {
                gMin = mins[i].getMinResult();
            }

            if (maxs[i].getMaxResult() > gMax) {
                gMax = maxs[i].getMaxResult();
            }
        }

        System.out.printf(
                "Global Min Temp: %.2f °C | Global Max Temp: %.2f °C%n",
                gMin, gMax
        );
    }
}
