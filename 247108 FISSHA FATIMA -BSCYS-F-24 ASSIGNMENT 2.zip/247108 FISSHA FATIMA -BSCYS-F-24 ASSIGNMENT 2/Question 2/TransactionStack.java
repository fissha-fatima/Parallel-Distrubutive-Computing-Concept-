
public class TransactionStack {
    private char[] array;
    private int top;

    public TransactionStack(int capacity) {
        array = new char[capacity];
        top = -1;
    }

    public void push(char c) {
        if (top < array.length - 1) {
            array[++top] = c;
        }
    }

    public char pop() {
        return isEmpty() ? '\0' : array[top--];
    }

    public boolean isEmpty() {
        return top == -1;
    }
}

