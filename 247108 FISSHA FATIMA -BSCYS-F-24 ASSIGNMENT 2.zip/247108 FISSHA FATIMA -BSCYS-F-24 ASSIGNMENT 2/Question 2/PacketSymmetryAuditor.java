
public class PacketSymmetryAuditor {

    public static void auditPacket(String payload) {
        int len = payload.length();

        TransactionStack stack = new TransactionStack(len);
        RequestQueue queue = new RequestQueue(len);

        for (int i = 0; i < len; i++) {
            char c = payload.charAt(i);
            stack.push(c);
            queue.enqueue(c);
        }

        boolean isSymmetric = true;

        while (!stack.isEmpty() && !queue.isEmpty()) {
            if (stack.pop() != queue.dequeue()) {
                isSymmetric = false;
                break;
            }
        }

        System.out.println("Payload: \"" + payload + "\" -> "
                + (isSymmetric
                ? "VERIFIED SYMMETRIC (Palindrome Passed)"
                : "REJECTED ASYMMETRIC"));
    }

    public static void main(String[] args) {
        System.out.println("=== Microservice Packet Symmetry Auditor ===");

        auditPacket("HDR10101RDH");
        auditPacket("DATASTREAM12");
        auditPacket("SIG001001GIS");
    }
}
