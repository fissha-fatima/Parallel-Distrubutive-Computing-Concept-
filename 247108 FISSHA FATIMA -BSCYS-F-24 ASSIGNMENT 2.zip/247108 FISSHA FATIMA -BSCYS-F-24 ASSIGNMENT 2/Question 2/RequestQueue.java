
public class RequestQueue {
    private char[] array;
    private int front, rear, size;

    public RequestQueue(int capacity) {
        array = new char[capacity];
        front = 0;
        rear = -1;
        size = 0;
    }

    public void enqueue(char c) {
        if (size < array.length) {
            rear = (rear + 1) % array.length;
            array[rear] = c;
            size++;
        }
    }

    public char dequeue() {
        if (isEmpty()) {
            return '\0';
        }

        char c = array[front];
        front = (front + 1) % array.length;
        size--;

        return c;
    }

    public boolean isEmpty() {
        return size == 0;
    }
}
