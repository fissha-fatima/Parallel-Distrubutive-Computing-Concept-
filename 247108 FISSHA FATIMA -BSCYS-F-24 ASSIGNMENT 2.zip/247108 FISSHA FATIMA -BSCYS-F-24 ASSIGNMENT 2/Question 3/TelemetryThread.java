
public class TelemetryThread extends Thread {

    public TelemetryThread(String name) {
        super(name);
    }

    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("[Telemetry-Worker] Iteration " + i
                    + " | Thread: " + getName());

            try {
                Thread.sleep(800);
            } catch (InterruptedException e) {
                System.err.println(e.getMessage());
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}
