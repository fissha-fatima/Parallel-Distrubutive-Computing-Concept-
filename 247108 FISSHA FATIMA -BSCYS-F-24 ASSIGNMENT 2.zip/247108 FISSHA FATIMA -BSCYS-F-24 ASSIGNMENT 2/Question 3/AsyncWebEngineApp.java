
public class AsyncWebEngineApp {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Primary Entry Thread: "
                + Thread.currentThread().getName());

        TelemetryThread telemetryThread =
                new TelemetryThread("Telemetry-Worker");

        Thread logThread =
                new Thread(new LogProcessorTask(), "Log-Worker");

        telemetryThread.start();
        logThread.start();

        telemetryThread.join();
        logThread.join();

        System.out.println("All diagnostics completed cleanly.");
    }
}
