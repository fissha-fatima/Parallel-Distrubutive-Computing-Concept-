
import java.util.concurrent.RecursiveAction;

public class PortfolioThresholdTask extends RecursiveAction {

    private final double[] assets;
    private final int start, end;
    private final double cap;
    private static final int THRESHOLD = 1000;

    public PortfolioThresholdTask(double[] assets, int start,
                                  int end, double cap) {
        this.assets = assets;
        this.start = start;
        this.end = end;
        this.cap = cap;
    }

    @Override
    protected void compute() {
        if ((end - start) <= THRESHOLD) {
            for (int i = start; i < end; i++) {
                if (assets[i] > cap) {
                    assets[i] *= 1.05;
                }
            }
        } else {
            int mid = (start + end) / 2;

            invokeAll(
                new PortfolioThresholdTask(assets, start, mid, cap),
                new PortfolioThresholdTask(assets, mid, end, cap)
            );
        }
    }
}
