
import java.util.Random;
import java.util.concurrent.ForkJoinPool;

public class ForkJoinPortfolioApp {

    public static void main(String[] args) {
        int size = 10000;
        double[] assets = new double[size];

        Random rnd = new Random(42);

        for (int i = 0; i < size; i++) {
            assets[i] = 100 + rnd.nextDouble() * 900;
        }

        ForkJoinPool pool = new ForkJoinPool();

        long start = System.nanoTime();

        pool.invoke(
            new PortfolioThresholdTask(assets, 0, size, 500.0)
        );

        double totalRisk = pool.invoke(
            new ParallelRiskCalculator(assets, 0, size)
        );

        long elapsed = System.nanoTime() - start;

        System.out.printf(
            "Total Risk Score: $%.2f | Processing Time: %.3f ms%n",
            totalRisk, elapsed / 1e6
        );

        pool.shutdown();
    }
}
