
public class CacheLocalityBenchmark {

    private static final int SIZE = 2000;
    private static final int ITERATIONS = 10;

    public static void main(String[] args) {
        double[][] matrix = new double[SIZE][SIZE];

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                matrix[i][j] = i + j * 0.5;
            }
        }

        System.out.println(
                "=== CPU Cache Locality Memory Profiling Benchmark ===");

        long startRow = System.nanoTime();

        for (int it = 0; it < ITERATIONS; it++) {
            traverseRowMajor(matrix);
        }

        long timeRow =
                (System.nanoTime() - startRow) / ITERATIONS;

        long startCol = System.nanoTime();

        for (int it = 0; it < ITERATIONS; it++) {
            traverseColumnMajor(matrix);
        }

        long timeCol =
                (System.nanoTime() - startCol) / ITERATIONS;

        double rMs = timeRow / 1e6;
        double cMs = timeCol / 1e6;

        System.out.printf(
                "Row-Major Time (Stride-1):    %.3f ms%n", rMs);

        System.out.printf(
                "Column-Major Time (Stride-N): %.3f ms%n", cMs);

        if (timeRow > 0) {
            double speedup = timeCol / (double) timeRow;
            System.out.printf(
                    "Row-Major Speedup vs Column-Major: %.2fx%n",
                    speedup);
        }
    }

    public static double traverseRowMajor(double[][] mat) {
        if (mat == null || mat.length == 0 || mat[0].length == 0) {
            return 0.0;
        }

        double sum = 0;
        int rows = mat.length;
        int cols = mat[0].length;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                sum += mat[i][j];
            }
        }

        return sum;
    }

    public static double traverseColumnMajor(double[][] mat) {
        if (mat == null || mat.length == 0 || mat[0].length == 0) {
            return 0.0;
        }

        double sum = 0;
        int rows = mat.length;
        int cols = mat[0].length;

        for (int j = 0; j < cols; j++) {
            for (int i = 0; i < rows; i++) {
                sum += mat[i][j];
            }
        }

        return sum;
    }
}
